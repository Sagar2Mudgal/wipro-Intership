package com.wipro;

public class SetterMessage {
	private String message = null;
	
	public SetterMessage() {
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
